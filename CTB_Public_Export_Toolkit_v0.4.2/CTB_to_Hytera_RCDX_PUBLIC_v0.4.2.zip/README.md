# Motorola CPS1 CTB → Hytera PD782 RCDX (v0.4.2)

## Run: zero arguments

```sh
python 2_Hytera_RCDX_Creator.py
```

Automatically finds one `.ctb`, `codeplug.cfg`, and **one** genuine compatible PD782/PD782i donor `.rcdx`. For donor `handheld.rcdx`, outputs `handheld-out.rcdx` plus `handheld-out.audit.json`, beside the donor. Existing files are never overwritten.

If files are ambiguous, the tool displays this manual syntax:

```sh
python 2_Hytera_RCDX_Creator.py --ctbimport radio.ctb --donor clean-PD782.rcdx
```

Use `--config PATH`, `--output PATH`, or `--no-extract` as needed. Legacy positional CTB syntax remains supported.

The RCDX file-container is encrypted and must be decoded/re-encoded to edit programming. This does **not** decrypt the voice codec or live radio traffic. Only recognized PD782 programming sections are edited; other proprietary donor fields remain and require CPS review. Motorola QCII receive/decode behavior is not imported; only supported transmit contacts are migrated.

## First-time setup

1. Install Python 3.9+ and dependencies: `python -m pip install -r requirements.txt` (or `python3 -m pip ...` on WSL/Linux).
2. **Go to https://github.com/jhsonthego-create/CTB-decoder** and follow its instructions to create your own private `codeplug.cfg`.
3. Put `codeplug.cfg` and **one** source `.ctb` in the directory where you run the converter. Put the compatible donor there too if your destination needs one.
4. Run **script #2** without arguments.

No key creator, AES key/IV, vendor CPS file, private codeplug, or donor radio file is bundled.

**Config search:** current working directory first, then the script directory. `--config PATH` overrides both. An invalid/missing config displays a large error banner including the GitHub URL. Never post or share `codeplug.cfg`.

**Auto-discovery:** scans the working directory first; if no matching input files exist, looks beside the scripts. No arbitrary picks: when there are multiple candidates, it shows the manual command instead of prompting or guessing. Previously generated `-out` files are excluded from automatic donor discovery. Existing output and audit files are never overwritten.

## What the scripts do

- `1_CTB_Decode_Tester.py` — optional tester/inspector. Reads and verifies Motorola CTB; **does not create destination files**. Run it with **no arguments** to inspect the only `.ctb` in the working directory (or script directory if none); otherwise specify `--ctbimport radio.ctb` or the legacy positional `radio.ctb`. If multiple CTBs are found, it displays the manual command instead of guessing.
- `2_Hytera_RCDX_Creator.py` — **run this to convert**.
- `tools/Motorola_TwoTone_Translator.py` — **internal helper**, imported automatically; **does absolutely nothing to a codeplug when executed directly**. Running it only displays the supplied large **THIS IS NOT AN INDEPENDENT SCRIPT** banner. Do not run it as a converter.
- `tools/public_runtime.py` — file discovery, no-overwrite checks and local extraction support.

## Decoded-data folders

After a successful conversion, timestamped directories appear in the current working directory: `radio_YYYYMMDD_HHMM/` for source CTB, plus `donor_YYYYMMDD_HHMM/` where a donor exists. One timestamp is captured at invocation start and reused across every extraction, including CS711/CS811 runs. If the folder exists, a unique `-2`, `-3`, etc. suffix avoids overwriting.

- CTB: `decrypted_codeplug.xml` (normalized, signature-verified source XML), `decoded_model.json`, `metadata.json`.
- Connect Systems RDB: `original_records.bin`, `decoded_records.json` (known record fields only), `metadata.json`. **RDB is not encrypted**.
- Hytera RCDX: `decrypted_payload.bin`, `decoded_records.json`, `section_index.json`, `metadata.json`. This is **file-container** decoding, not voice traffic or a voice codec.

Use `--no-extract` to skip these local folders. They can contain sensitive radio identities, system settings and donor data. They are **never included** in the downloadable public release ZIPs. You may move/rename these folders after conversion.

## Safety

**Quick Call II:** `CALLFMT_AB_CD` is decoded as the separate A-B and C-D tone pairs, with both sets of frequencies preserved. Original combined-system call logic and destination CPS/radio equivalence are **not verified**.

**Experimental converters, not CPS-verified.** Successful decryption, binary roundtrips, and record readback do **not** establish destination CPS acceptance or safe radio operation. Open, inspect, save, close and reopen each output in the matching destination CPS and verify frequencies, model/band, channel settings, IDs, groups, scan/roam, two-tone/QCII, privacy/encryption settings, donor hardware identifiers and retained proprietary fields before programming. Never distribute a converted donor without checking its identity and sensitive settings. Unsupported features are documented in audit reports and may not migrate.

**MIT License** retained. Release ZIPs have SHA256 hashes in the master manifest. No private keys or codeplugs are included.
