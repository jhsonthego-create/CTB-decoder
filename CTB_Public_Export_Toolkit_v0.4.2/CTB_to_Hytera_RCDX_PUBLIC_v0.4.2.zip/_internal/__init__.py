"""Internal RCDX container and record parsing. Not user-facing commands."""
