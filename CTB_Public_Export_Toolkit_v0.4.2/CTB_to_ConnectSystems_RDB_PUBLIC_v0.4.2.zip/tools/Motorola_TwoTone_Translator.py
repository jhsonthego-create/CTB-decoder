#!/usr/bin/env python3
"""Source-only Motorola QCII -> observed CS711/CS811 two-tone tables.

No donor tone definitions survive. This module is based on original Motorola
CPS1 QCII system/contact XML and the user's CPS-saved 376,832-byte RDB samples.
CPS GUI/radio behavior of reconstructed two-tone fields is NOT yet verified.
"""
from __future__ import annotations
import struct
from decimal import Decimal, InvalidOperation

DECODE_OFFSET=0x3E520
DECODE_COUNT=16
DECODE_SIZE=8
ENCODE_OFFSET=0x3E5A0
ENCODE_COUNT=32
ENCODE_SIZE=16
ENCODE_END=ENCODE_OFFSET+ENCODE_COUNT*ENCODE_SIZE
NEXT_TABLE_OFFSET=0x3E7C0


def _text(node,tag,default=None):
    item=node.find(tag)
    return default if item is None or item.text is None else item.text.strip()


def _frequency(raw,context):
    try:hz=Decimal(raw)
    except (InvalidOperation,TypeError):raise ValueError(f'{context}: missing/invalid frequency {raw!r}')
    if hz<Decimal('200.0') or hz>Decimal('2500.0') or hz*10!=(hz*10).to_integral_value():
        raise ValueError(f'{context}: frequency {raw!r} is outside observed 200–2500 Hz / 0.1 Hz resolution')
    return int(hz*10)


def _tone_fields(node,first,second,context):
    return _frequency(_text(node,first),context+' A'),_frequency(_text(node,second),context+' B')


def _source_contacts(root):
    grp=root.find('.//QCII_UCL_DLH_TYPE_GRP')
    if grp is None:return []
    return grp.findall('.//QCII_UCL_DLL_TYPE')


def read_motorola_qcii(root):
    """Separate QCII decode systems from QCII transmit contacts.

    Motorola initializes most untouched CPS1 CTBs with an inactive Sys1 and
    a 288.5/288.5-Hz Call1. These are placeholders, NOT programmed tones.
    """
    systems={}
    for n in root.findall('.//QCII_SYS_CMP_TYPE_GRP/QCII_SYS_CMP_TYPE'):
        sid=int(n.get('ListID','-1'))
        if sid in systems:raise ValueError('Duplicate Motorola QCII system ID '+str(sid))
        systems[sid]=n
    decoded=[];system_audit=[];active_systems=set()
    for sid,n in systems.items():
        calltype=_text(n,'QCIISYS_CALLTYPE','NONE')
        alias=_text(n,'QCIISYS_QCIISYSALIAS',f'Sys{sid}')
        fmt=_text(n,'QCIISYS_FORMATTYPE','')
        if calltype=='NONE':
            system_audit.append({'source_id':sid,'name':alias,'state':'inactive-default-or-unconfigured','imported':False})
            continue
        if calltype!='SELECTIVE_CALL':
            raise ValueError(f'QCII system {alias!r}: unsupported call type {calltype!r}')
        a,b=_tone_fields(n,'QCIISYS_TONEARF','QCIISYS_TONEBRF',alias)
        if fmt not in ('CALLFMT_AB','CALLFMT_AB_LONG_C','CALLFMT_AB_CD'):
            raise ValueError(f'QCII system {alias!r}: unsupported format {fmt!r}')
        decoded.append({'source_kind':'system A-B','source_id':sid,'name':alias+' A-B',
                        'format':'Two Tone','tone_a_tenths':a,'tone_b_tenths':b})
        if fmt=='CALLFMT_AB_LONG_C':
            c=_frequency(_text(n,'QCIISYS_TONECRF'),alias+' Long C')
            decoded.append({'source_kind':'system Long C','source_id':sid,'name':alias+' Long C',
                            'format':'Long Tone','tone_a_tenths':c,'tone_b_tenths':c})
        elif fmt=='CALLFMT_AB_CD':
            c,d=_tone_fields(n,'QCIISYS_TONECRF','QCIISYS_TONEDRF',alias+' C-D')
            decoded.append({'source_kind':'system C-D','source_id':sid,'name':alias+' C-D',
                            'format':'Two Tone','tone_a_tenths':c,'tone_b_tenths':d})
        active_systems.add(sid)
        system_audit.append({'source_id':sid,'name':alias,'state':calltype,'format':fmt,
                             'imported':True,'decode_definitions':2 if fmt in ('CALLFMT_AB_LONG_C','CALLFMT_AB_CD') else 1,
                             'note':'Motorola combined-system logic may not be equivalent to separate destination decode entries; verify in CPS/radio'})
    if len(decoded)>DECODE_COUNT:
        raise ValueError(f'Motorola QCII needs {len(decoded)} decode entries, CS observed capacity {DECODE_COUNT}')

    encoded=[];contact_audit=[];contact_ids=set()
    for n in _source_contacts(root):
        cid=int(n.get('ListLetID','-1'))
        if cid in contact_ids:raise ValueError('Duplicate Motorola QCII contact ID '+str(cid))
        contact_ids.add(cid)
        name=_text(n,'QU_CALLENTRYALIAS',f'Call{cid}')
        fmt=_text(n,'QU_CALLFORMAT','')
        sid=int(_text(n,'QU_QCIISYS','-1'))
        if sid not in systems:
            raise ValueError(f'QCII contact {name!r} references missing system {sid}')
        a,b=_tone_fields(n,'QU_TONEATXFRE','QU_TONEBTXFRE',name)
        # The CPS-created empty template is not a user-programmed QCII entry.
        is_default=(cid==0 and name=='Call1' and fmt=='TWO_TONE'
                    and a==2885 and b==2885)
        if is_default:
            contact_audit.append({'source_id':cid,'name':name,'state':'Motorola-default-placeholder','imported':False})
            continue
        if fmt not in ('TWO_TONE','LONG_TONE'):
            raise ValueError(f'QCII contact {name!r}: unsupported format {fmt!r}')
        # In a LONG_TONE contact the B frequency is disabled. Ignore it.
        if fmt=='LONG_TONE':b=a
        encoded.append({'source_id':cid,'source_system_id':sid,'name':name,
                        'format':'Two Tone' if fmt=='TWO_TONE' else 'Long Tone',
                        'tone_a_tenths':a,'tone_b_tenths':b})
        contact_audit.append({'source_id':cid,'name':name,'state':'programmed','imported':True,
                              'format':fmt,'tone_a_hz':a/10,'tone_b_hz':b/10})
    if len(encoded)>ENCODE_COUNT:
        raise ValueError(f'Motorola QCII needs {len(encoded)} encode entries, CS observed capacity {ENCODE_COUNT}')
    return {'decode':decoded,'encode':encoded,'source_systems':system_audit,
            'source_contacts':contact_audit,'motorola_placeholder_contacts_skipped':sum(not x['imported'] for x in contact_audit)}


def _alias8(s,idx,seen):
    # Observed CS encode labels are 8 bytes, ASCII, zero-padded.
    name=''.join(c if 32<=ord(c)<=126 else '_' for c in s).strip()[:8]
    if not name:name=f'Tone{idx}'
    if name.casefold() in seen:
        suffix=str(idx);name=name[:8-len(suffix)]+suffix
    if name.casefold() in seen:raise ValueError('QCII encode label collision: '+name)
    seen.add(name.casefold());return name


def patch_qcii_tables(buf,source,donor):
    """Clear BOTH donor decode/encode tables, then import source-derived values."""
    if len(buf)!=376832 or len(donor)!=len(buf):raise ValueError('Unsupported CS RDB length')
    # Verify we are editing the known table format before writing. Unmapped
    # tables must not be overwritten as though they were known.
    for i in range(DECODE_COUNT):
        a,b,kind,flags=struct.unpack_from('<HHHH',donor,DECODE_OFFSET+i*DECODE_SIZE)
        if (a,b,kind,flags)!=(0,0,0,0) and (kind not in (0x0126,0x0122) or flags!=0x0300):
            raise ValueError(f'Unrecognized donor QCII decode record #{i+1}; refusing binary patch')
    for i in range(ENCODE_COUNT):
        rec=donor[ENCODE_OFFSET+i*ENCODE_SIZE:ENCODE_OFFSET+(i+1)*ENCODE_SIZE]
        if not any(rec):continue
        flag,a,b,terminator=struct.unpack_from('<HHHH',rec)
        if flag not in (0,0x10,0x14) or terminator!=0xffff:
            raise ValueError(f'Unrecognized donor QCII encode record #{i+1}: {rec.hex()}')
    if any(donor[ENCODE_END:NEXT_TABLE_OFFSET]):
        raise ValueError('Unexpected nonzero bytes between QCII encode table and next RDB section')
    buf[DECODE_OFFSET:DECODE_OFFSET+DECODE_COUNT*DECODE_SIZE]=bytes(DECODE_COUNT*DECODE_SIZE)
    buf[ENCODE_OFFSET:ENCODE_END]=bytes(ENCODE_COUNT*ENCODE_SIZE)
    seen=set()
    for i,x in enumerate(source['decode']):
        kind=0x0126 if x['format']=='Two Tone' else 0x0122
        struct.pack_into('<HHHH',buf,DECODE_OFFSET+i*DECODE_SIZE,
                         x['tone_a_tenths'],x['tone_b_tenths'],kind,0x0300)
    for i,x in enumerate(source['encode']):
        # CPS-saved examples show 0x0014 for ordinary two-tone transmissions,
        # 0x0000 for long-tone. The timing/control meaning is not independently
        # decoded; this is explicitly reported as a donor-template assumption.
        flag=0x14 if x['format']=='Two Tone' else 0
        name=_alias8(x['name'],i+1,seen).encode('ascii').ljust(8,b'\0')
        struct.pack_into('<HHHH8s',buf,ENCODE_OFFSET+i*ENCODE_SIZE,
                         flag,x['tone_a_tenths'],x['tone_b_tenths'],0xffff,name)
    verify_qcii_tables(bytes(buf),source)
    return {'two_tone_decode_count':len(source['decode']),
            'two_tone_encode_count':len(source['encode']),
            'donor_two_tone_decode_cleared':True,'donor_two_tone_encode_cleared':True,
            'motorola_placeholder_contacts_skipped':source['motorola_placeholder_contacts_skipped'],
            'two_tone_decode_records':source['decode'],'two_tone_encode_records':source['encode'],
            'two_tone_source_system_audit':source['source_systems'],
            'two_tone_source_contact_audit':source['source_contacts'],
            'two_tone_limitations':'Motorola combined QCII formats (A-B/Long C and A-B/C-D) are split into separate CS decode entries; original combined call logic and CS encode timing/control not CPS-confirmed. Decode/encode definitions do not prove channel-level signaling behavior.'}


def verify_qcii_tables(b,source):
    dec=source['decode'];enc=source['encode'];checks=0
    for i in range(DECODE_COUNT):
        r=struct.unpack_from('<HHHH',b,DECODE_OFFSET+i*DECODE_SIZE)
        if i<len(dec):
            x=dec[i];expected=(x['tone_a_tenths'],x['tone_b_tenths'],0x0126 if x['format']=='Two Tone' else 0x0122,0x0300)
        else:expected=(0,0,0,0)
        if r!=expected:raise AssertionError(f'QCII decode mismatch #{i+1}: {r} != {expected}')
        checks+=1
    for i in range(ENCODE_COUNT):
        r=b[ENCODE_OFFSET+i*ENCODE_SIZE:ENCODE_OFFSET+(i+1)*ENCODE_SIZE]
        if i<len(enc):
            x=enc[i];flag,a,bb,terminator=struct.unpack_from('<HHHH',r)
            if (flag,a,bb,terminator)!=(0x14 if x['format']=='Two Tone' else 0,x['tone_a_tenths'],x['tone_b_tenths'],0xffff):
                raise AssertionError('QCII encode mismatch '+str(i+1))
            if not r[8:16].split(b'\0')[0]:raise AssertionError('QCII missing encode name '+str(i+1))
        elif any(r):raise AssertionError('Donor QCII encode leakage at slot '+str(i+1))
        checks+=1
    return checks


if __name__ == "__main__":
    print('*****************************************************************************\n*****************************************************************************\n*************                                           *********************\n*************  THIS IS NOT AN INDEPENDENT SCRIPT        *********************\n*************                                           *********************\n*****************************************************************************\n*****************************************************************************')
    print("\n  This is an internal helper; it does no conversion when run directly.")
    print("  Run the 2_*_Creator.py script instead.\n")
