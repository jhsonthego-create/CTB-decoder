"""No private codeplugs, signing secrets or real user tone profiles required."""
import sys,struct,unittest
from pathlib import Path
from lxml import etree
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import importlib
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
translator=importlib.import_module("tools.Motorola_TwoTone_Translator")
read_motorola_qcii=translator.read_motorola_qcii
patch_qcii_tables=translator.patch_qcii_tables
verify_qcii_tables=translator.verify_qcii_tables
DECODE_OFFSET,DECODE_COUNT,DECODE_SIZE=translator.DECODE_OFFSET,translator.DECODE_COUNT,translator.DECODE_SIZE
ENCODE_OFFSET,ENCODE_COUNT,ENCODE_SIZE=translator.ENCODE_OFFSET,translator.ENCODE_COUNT,translator.ENCODE_SIZE


def make_xml(system='NONE',fmt='CALLFMT_AB',contacts=None):
    root=etree.Element('LTD_CODEPLUG')
    g=etree.SubElement(root,'QCII_SYS_CMP_TYPE_GRP')
    n=etree.SubElement(g,'QCII_SYS_CMP_TYPE',ListID='0')
    for tag,v in [('QCIISYS_CALLTYPE',system),('QCIISYS_FORMATTYPE',fmt),
                  ('QCIISYS_QCIISYSALIAS','Sys1'),('QCIISYS_TONEARF','617.4'),
                  ('QCIISYS_TONEBRF','726.8'),('QCIISYS_TONECRF','810.2'),('QCIISYS_TONEDRF','928.1')]:
        etree.SubElement(n,tag).text=v
    h=etree.SubElement(root,'QCII_UCL_DLH_TYPE_GRP')
    p=etree.SubElement(h,'QCII_UCL_DLT_TYPE')
    for i,(alias,kind,a,b) in enumerate(contacts or []):
        c=etree.SubElement(p,'QCII_UCL_DLL_TYPE',ListLetID=str(i))
        for tag,v in [('QU_CALLENTRYALIAS',alias),('QU_CALLFORMAT',kind),
                      ('QU_TONEATXFRE',a),('QU_TONEBTXFRE',b),('QU_QCIISYS','0')]:
            etree.SubElement(c,tag).text=v
    return root


def contaminated_donor():
    b=bytearray(376832)
    b[0x2000:0x2005]=b'CS711'
    for i in range(DECODE_COUNT):
        struct.pack_into('<HHHH',b,DECODE_OFFSET+i*8,5848,6174,0x0126,0x0300)
    for i in range(5):
        struct.pack_into('<HHHH8s',b,ENCODE_OFFSET+i*16,0x14,5848,6174,0xffff,b'DONOR'+bytes([48+i])+b'\0\0')
    return bytes(b)

class TestQCII(unittest.TestCase):
    def test_empty_source_erases_all_donor_tones(self):
        src=read_motorola_qcii(make_xml(contacts=[('Call1','TWO_TONE','288.5','288.5')]))
        self.assertEqual(len(src['decode']),0)
        self.assertEqual(len(src['encode']),0)
        b=bytearray(contaminated_donor());patch_qcii_tables(b,src,bytes(b))
        self.assertFalse(any(b[DECODE_OFFSET:DECODE_OFFSET+DECODE_COUNT*8]))
        self.assertFalse(any(b[ENCODE_OFFSET:ENCODE_OFFSET+ENCODE_COUNT*16]))
        self.assertEqual(verify_qcii_tables(b,src),48)
    def test_active_ab_long_c_and_contacts(self):
        src=read_motorola_qcii(make_xml('SELECTIVE_CALL','CALLFMT_AB_LONG_C',
            [('ExampleA','TWO_TONE','617.4','726.8'),('ExampleLong','LONG_TONE','810.2','288.5'),
             ('ExampleB','TWO_TONE','617.4','903.2')]))
        self.assertEqual((len(src['decode']),len(src['encode'])),(2,3))
        b=bytearray(contaminated_donor());patch_qcii_tables(b,src,bytes(b))
        self.assertEqual(struct.unpack_from('<HHHH',b,DECODE_OFFSET),(6174,7268,0x0126,0x0300))
        self.assertEqual(struct.unpack_from('<HHHH',b,DECODE_OFFSET+8),(8102,8102,0x0122,0x0300))
        self.assertEqual(struct.unpack_from('<HHHH',b,ENCODE_OFFSET+16),(0,8102,8102,0xffff))
        self.assertFalse(any(b[ENCODE_OFFSET+3*16:ENCODE_OFFSET+ENCODE_COUNT*16]))
        self.assertEqual(verify_qcii_tables(b,src),48)
    def test_active_ab_cd_writes_two_source_decode_pairs(self):
        src=read_motorola_qcii(make_xml('SELECTIVE_CALL','CALLFMT_AB_CD'))
        self.assertEqual([(r['tone_a_tenths'],r['tone_b_tenths']) for r in src['decode']],
                         [(6174,7268),(8102,9281)])
        b=bytearray(contaminated_donor())
        patch_qcii_tables(b,src,bytes(b))
        self.assertEqual(struct.unpack_from('<HHHH',b,DECODE_OFFSET),(6174,7268,0x0126,0x0300))
        self.assertEqual(struct.unpack_from('<HHHH',b,DECODE_OFFSET+8),(8102,9281,0x0126,0x0300))
        self.assertEqual(verify_qcii_tables(b,src),48)

    def test_source_has_no_qcii_contacts(self):
        src=read_motorola_qcii(make_xml())
        self.assertEqual((len(src['decode']),len(src['encode'])),(0,0))
    def test_custom_call1_not_dropped(self):
        src=read_motorola_qcii(make_xml(contacts=[('Call1','TWO_TONE','617.4','726.8')]))
        self.assertEqual(len(src['encode']),1)
    def test_unrecognized_source_format_rejected(self):
        with self.assertRaisesRegex(ValueError,'unsupported format'):
            read_motorola_qcii(make_xml(contacts=[('Call2','QUAD_TONE','617.4','726.8')]))
    def test_unrecognized_donor_decode_record_rejected(self):
        src=read_motorola_qcii(make_xml())
        b=bytearray(contaminated_donor());struct.pack_into('<H',b,DECODE_OFFSET+4,0x9999)
        with self.assertRaisesRegex(ValueError,'Unrecognized donor QCII decode'):
            patch_qcii_tables(b,src,bytes(b))
    def test_unrecognized_donor_encode_record_rejected(self):
        src=read_motorola_qcii(make_xml())
        b=bytearray(contaminated_donor());struct.pack_into('<H',b,ENCODE_OFFSET+6,0)
        with self.assertRaisesRegex(ValueError,'Unrecognized donor QCII encode'):
            patch_qcii_tables(b,src,bytes(b))
    def test_duplicate_source_contacts_rejected(self):
        root=make_xml(contacts=[('A','TWO_TONE','617.4','726.8'),('B','TWO_TONE','617.4','903.2')])
        root.findall('.//QCII_UCL_DLL_TYPE')[1].set('ListLetID','0')
        with self.assertRaisesRegex(ValueError,'Duplicate Motorola QCII contact'):
            read_motorola_qcii(root)
    def test_tone_precision_rejected(self):
        with self.assertRaisesRegex(ValueError,'resolution'):
            read_motorola_qcii(make_xml(contacts=[('A','TWO_TONE','617.44','726.8')]))

if __name__=='__main__':unittest.main()
