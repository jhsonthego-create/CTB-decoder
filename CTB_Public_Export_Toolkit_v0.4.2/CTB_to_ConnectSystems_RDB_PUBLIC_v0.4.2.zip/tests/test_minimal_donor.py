"""Regression tests using synthetic RDB buffers; no private codeplugs/donors."""
import importlib
import struct
import sys
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
mod=importlib.import_module('2_ConnectSystems_RDB_Creator')


def source(modes=('FM','DMR'),with_scan=False,with_roam=False):
    channels=[]
    for i,mode in enumerate(modes,1):
        uuid=('scan1' if mode=='FM' and with_scan else
              'roam1' if mode=='DMR' and with_roam else None)
        channels.append({'index':i,'name':f'{mode}{i}','mode':mode,
                         'tx_mhz':151.82,'rx_mhz':151.82,'rx_only':False,
                         'auto_scan':False,'scan_roam_uuid':uuid,
                         'rx_tone_type':'CSQ','rx_tone_value':None,'rx_invert':False,
                         'tx_tone_type':'CSQ','tx_tone_value':None,'tx_invert':False,
                         'color_code':1,'timeslot':1,'rx_group':None,'contact_uuid':None})
    lists=[]
    if with_scan:
        lists.append({'type':'scan','uuid':'scan1','name':'Local scan','members':[{'channel_index':1}]})
    if with_roam:
        dig=next(i for i,ch in enumerate(channels,1) if ch['mode']=='DMR')
        lists.append({'type':'roam','uuid':'roam1','name':'Roam','members':[{'channel_index':dig}]})
    return {'channels':channels,'contacts':[],
            'zones':[{'name':'Zone 1','members':[{'channel_index':i} for i in range(1,len(channels)+1)]}],
            'rx_groups':[], 'scan_roam_lists':lists,'subscriber_id':1001,
            'source_format':'TEST','source_datamodel':'TEST','source_sha256':'0'*64,
            'two_tone':{'decode':[],'encode':[],'motorola_placeholder_contacts_skipped':0,
                        'source_systems':[],'source_contacts':[]}}


def donor(model):
    d=bytearray(mod.SIZE)
    d[0x2000:0x2005]=model.encode('ascii')
    d[0x2200:0x2200+len('ORIGINAL'.encode('utf-16le'))]='ORIGINAL'.encode('utf-16le')
    return bytes(d)


class MinimalDonorTests(unittest.TestCase):
    def test_both_modes_missing_uses_observed_model_templates(self):
        for model in ('CS711','CS811'):
            with self.subTest(model=model):
                raw,audit=mod.patch(source(),donor(model),model)
                self.assertEqual(len(raw),mod.SIZE)
                self.assertEqual({x.split()[0] for x in audit['fallback_templates_used']},{'FM','DMR'})
                self.assertEqual(raw[0x2200:0x2210],donor(model)[0x2200:0x2210])
                self.assertEqual(raw[mod.CH_AT+8],0x17)
                self.assertEqual(raw[mod.CH_AT+32+8],0x14)
                self.assertTrue(audit['requires_cps_template_verification'])
    def test_only_required_mode_is_needed(self):
        for model in ('CS711','CS811'):
            with self.subTest(model=model):
                _,audit=mod.patch(source(('FM',)),donor(model),model)
                self.assertEqual(len(audit['fallback_templates_used']),1)
                self.assertTrue(audit['fallback_templates_used'][0].startswith('FM'))
    def test_minimal_scan_roam_templates_are_created_only_when_needed(self):
        for model in ('CS711','CS811'):
            with self.subTest(model=model):
                _,audit=mod.patch(source(with_scan=True,with_roam=True),donor(model),model)
                self.assertTrue(any('scan list' in x for x in audit['fallback_templates_used']))
                self.assertTrue(any('roam list' in x for x in audit['fallback_templates_used']))
    def test_alias_default_preserves_donor_and_optional_override(self):
        for model in ('CS711','CS811'):
            with self.subTest(model=model):
                d=donor(model)
                raw,_=mod.patch(source(('FM',)),d,model)
                self.assertEqual(raw[0x2200:0x2210],d[0x2200:0x2210])
                renamed,_=mod.patch(source(('FM',)),d,model,alias='NEW NAME')
                self.assertEqual(renamed[0x2200:0x2210].decode('utf-16le'),'NEW NAME')
    def test_wrong_donor_model_is_still_rejected(self):
        with self.assertRaisesRegex(ValueError,'does not match'):
            mod.patch(source(),donor('CS811'),'CS711')

if __name__=='__main__':unittest.main()
