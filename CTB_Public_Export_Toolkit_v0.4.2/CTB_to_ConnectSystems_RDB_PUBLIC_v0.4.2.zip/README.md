# Motorola CPS1 CTB → Connect Systems CS711 / CS811 RDB (v0.4.2)

## Run: zero arguments

```sh
python 2_ConnectSystems_RDB_Creator.py
```

Automatically finds one `.ctb`, `codeplug.cfg`, and genuine `.rdb` donors. Inspects each RDB's internal model marker; when both matching models are present, runs **both CS711 and CS811** in the same invocation. A valid donor is only used for its identified model.

For `jason.rdb`, output is `jason-out.rdb` plus `jason-out.audit.json`. With two distinct donors, each produces its own `-out.rdb` and `.audit.json` file. Outputs are located beside their corresponding donors, and existing files are never overwritten.

If inputs are ambiguous, supply a manual command; no prompts are shown:

```sh
python 2_ConnectSystems_RDB_Creator.py --ctbimport radio.ctb --donor clean-CS711.rdb --model CS711
python 2_ConnectSystems_RDB_Creator.py --ctbimport radio.ctb --donor clean-CS811.rdb --model CS811
```

Use `--config PATH`, `--output PATH` or `--no-extract` if necessary. `--alias` is an advanced compatibility option that replaces the destination radio-name field; by default the existing donor radio name is preserved. No trailing positional `[ctb]` is required or accepted.

To run automatically with *both* models, provide **one genuine compatible RDB donor for each**. When only one donor model is present, only that model is generated (no bogus error about the other model). With multiple compatible donors, both models are processed. Ambiguous donors require an explicit manual command.

**Minimal / blank donors:** A donor may lack an FM channel, a DMR channel, or any scan/roam records. Version 0.4.1 uses previously observed, sanitized model-specific record templates only for the needed missing records. The audit identifies each fallback, and a conspicuous warning requires destination CPS open/save/reopen verification. No actual source/donor channel programming is taken from a packaged reference file. This improves compatibility with minimally configured RDBs but **does not prove every donor variant is compatible**. The original donor's radio-name field is preserved unless explicitly overridden.

QCII: clear the donor's decode **and** encode tables before migrating source-derived Quick Call II. The Motorola A-B/Long C combined behavior may not match destination CPS exactly; verify it. Current RDB mapping supports one nonempty RX group, and unverified DMR All Call mapping is rejected.

## First-time setup

1. Install Python 3.9+ and dependencies: `python -m pip install -r requirements.txt` (or `python3 -m pip ...` on WSL/Linux).
2. **Go to https://github.com/jhsonthego-create/CTB-decoder** and follow its instructions to create your own private `codeplug.cfg`.
3. Put `codeplug.cfg` and **one** source `.ctb` in the directory where you run the converter. Put the compatible donor there too if your destination needs one.
4. Run **script #2** without arguments.

No key creator, AES key/IV, vendor CPS file, private codeplug, or donor radio file is bundled.

**Config search:** current working directory first, then the script directory. `--config PATH` overrides both. An invalid/missing config displays a large error banner including the GitHub URL. Never post or share `codeplug.cfg`.

**Auto-discovery:** scans the working directory first; if no matching input files exist, looks beside the scripts. No arbitrary picks: when there are multiple candidates, it shows the manual command instead of prompting or guessing. Previously generated `-out` files are excluded from automatic donor discovery. Existing output and audit files are never overwritten.

## What the scripts do

- `1_CTB_Decode_Tester.py` — optional tester/inspector. Reads and verifies Motorola CTB; **does not create destination files**. Run it with **no arguments** to inspect the only `.ctb` in the working directory (or script directory if none); otherwise specify `--ctbimport radio.ctb` or the legacy positional `radio.ctb`. If multiple CTBs are found, it displays the manual command instead of guessing.
- `2_ConnectSystems_RDB_Creator.py` — **run this to convert**.
- `tools/Motorola_TwoTone_Translator.py` — **internal helper**, imported automatically; **does absolutely nothing to a codeplug when executed directly**. Running it only displays the supplied large **THIS IS NOT AN INDEPENDENT SCRIPT** banner. Do not run it as a converter.
- `tools/public_runtime.py` — file discovery, no-overwrite checks and local extraction support.

## Decoded-data folders

After a successful conversion, timestamped directories appear in the current working directory: `radio_YYYYMMDD_HHMM/` for source CTB, plus `donor_YYYYMMDD_HHMM/` where a donor exists. One timestamp is captured at invocation start and reused across every extraction, including CS711/CS811 runs. If the folder exists, a unique `-2`, `-3`, etc. suffix avoids overwriting.

- CTB: `decrypted_codeplug.xml` (normalized, signature-verified source XML), `decoded_model.json`, `metadata.json`.
- Connect Systems RDB: `original_records.bin`, `decoded_records.json` (known record fields only), `metadata.json`. **RDB is not encrypted**.
- Hytera RCDX: `decrypted_payload.bin`, `decoded_records.json`, `section_index.json`, `metadata.json`. This is **file-container** decoding, not voice traffic or a voice codec.

Use `--no-extract` to skip these local folders. They can contain sensitive radio identities, system settings and donor data. They are **never included** in the downloadable public release ZIPs. You may move/rename these folders after conversion.

## Safety

**Quick Call II:** `CALLFMT_AB_CD` is decoded as the separate A-B and C-D tone pairs, with both sets of frequencies preserved. Original combined-system call logic and destination CPS/radio equivalence are **not verified**.

**Experimental converters, not CPS-verified.** Successful decryption, binary roundtrips, and record readback do **not** establish destination CPS acceptance or safe radio operation. Open, inspect, save, close and reopen each output in the matching destination CPS and verify frequencies, model/band, channel settings, IDs, groups, scan/roam, two-tone/QCII, privacy/encryption settings, donor hardware identifiers and retained proprietary fields before programming. Never distribute a converted donor without checking its identity and sensitive settings. Unsupported features are documented in audit reports and may not migrate.

**MIT License** retained. Release ZIPs have SHA256 hashes in the master manifest. No private keys or codeplugs are included.
