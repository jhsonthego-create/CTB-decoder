#!/usr/bin/env python3
"""Shared Motorola CPS1 CTB (MATRIX/GEMSTONE) verified decoder and programming model.

Experimental, no radio programming: destination CPS open/save/reopen required.
Source CTB is never modified. The exact raw Motorola CTB
payload is verified with its embedded RSA/SHA1 signature before conversion.
No CPS DLL, user codeplug, AES material or signing certificate embedded.
"""
from __future__ import annotations
import argparse,base64,configparser,gzip,hashlib,html,json,re,sys
from pathlib import Path
from collections import Counter
from lxml import etree
from cryptography.hazmat.primitives.ciphers import Cipher,algorithms,modes
from cryptography.hazmat.primitives.padding import PKCS7
from cryptography.hazmat.primitives.asymmetric import padding as asym_padding
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric.rsa import RSAPublicNumbers
import importlib
from tools.public_runtime import find_config, one_file, DiscoveryError
read_motorola_qcii = importlib.import_module("tools.Motorola_TwoTone_Translator").read_motorola_qcii


def require(cond,msg):
    if not cond:raise ValueError(msg)


def matrix_charstream_to_bytes(text):
    # Motorola CPS1 MATRIX <RADIO> serializes binary ciphertext as Windows-1252
    # characters, escaped with XML numeric references for low controls. Python's
    # html.unescape would corrupt &#x0;..&#x1f; by HTML5 replacement rules.
    text=re.sub(r'&#(?:x([0-9A-Fa-f]+)|([0-9]+));',
                lambda m:chr(int(m.group(1),16) if m.group(1) else int(m.group(2))),text)
    text=html.unescape(text)
    buf=bytearray()
    for char in text:
        try:buf.extend(char.encode('cp1252'))
        except UnicodeEncodeError:
            require(ord(char)<256, 'MATRIX ciphertext contains unexpected Unicode character U+%04X'%ord(char))
            buf.append(ord(char))
    return bytes(buf)


class CodeplugConfigError(ValueError):
    """Invalid/missing private CPS1 codeplug.cfg; print a clear user-facing banner."""


CONFIG_HELP_BANNER = r"""
*****************************************************************************
*****************************************************************************
*************                                           *********************
*************  CODEPLUG.CFG IS NOT FOUND OR INVALID     *********************
*************                                           *********************
*****************************************************************************
*****************************************************************************

  Go to https://github.com/jhsonthego-create/CTB-decoder.
  Follow the instructions to create your own codeplug.cfg.

  Put codeplug.cfg in the current directory or beside these scripts,
  or supply --config "/full/path/to/codeplug.cfg".

  Your private key/IV and CPS files must NEVER be shared or published.
"""


def _cfg_error(configfile, reason):
    return CodeplugConfigError(CONFIG_HELP_BANNER +
                               "\n  Config: " + str(configfile) +
                               "\n  Problem: " + str(reason) + "\n")


def load_aes_config(configfile):
    """Check file existence, INI syntax, key/IV names, base64, and exact sizes."""
    configfile = Path(configfile)
    if not configfile.is_file():
        raise _cfg_error(configfile, "File not found")
    cfg = configparser.ConfigParser(interpolation=None)
    try:
        with configfile.open('r', encoding='utf-8-sig') as stream:
            cfg.read_file(stream)
        if not cfg.has_section('codeplug'):
            raise ValueError("Missing [codeplug] section")
        if not cfg.has_option('codeplug', 'key') or not cfg.has_option('codeplug', 'iv'):
            raise ValueError("[codeplug] must contain key= and iv=")
        key = base64.b64decode(cfg.get('codeplug','key').strip(), validate=True)
        iv = base64.b64decode(cfg.get('codeplug','iv').strip(), validate=True)
        if len(key) != 32 or len(iv) != 16:
            raise ValueError("Expected a 32-byte AES key and a 16-byte IV")
    except Exception:
        # Never echo the INI contents: malformed files can contain private keys.
        raise _cfg_error(configfile,
            "Expected [codeplug] with a valid base64 key (32 bytes) and iv (16 bytes)") from None
    return key, iv


def decode_ctb(path,configfile):
    raw=Path(path).read_bytes()
    # Deliberately parse envelope without parsing the invalid numeric control
    # references in a MATRIX ciphertext as XML.
    typ=re.match(rb'<ARCHIVE\s+TYPE="(GEMSTONE|MATRIX|PARADISE_LIGHT)"',raw)
    require(typ is not None,'Unsupported CPS1 CTB archive type')
    kind=typ.group(1).decode('ascii')
    m=re.search(rb'<RADIO\s+VERSION="1"[^>]*>(.*?)</RADIO>',raw,re.S)
    require(m is not None, 'CTB missing RADIO payload')
    if kind=='MATRIX':
        encrypted=matrix_charstream_to_bytes(m.group(1).decode('utf-8'))
    else:
        encrypted=base64.b64decode(m.group(1).strip(),validate=True)
    require(encrypted and len(encrypted)%16==0,'Invalid AES ciphertext size')
    key,iv=load_aes_config(configfile)
    ctx=Cipher(algorithms.AES(key),modes.CBC(iv)).decryptor()
    padded=ctx.update(encrypted)+ctx.finalize()
    try:
        unpad=PKCS7(128).unpadder();compressed=unpad.update(padded)+unpad.finalize()
    except ValueError:
        raise _cfg_error(configfile, "Key/IV do not decrypt this CTB (or the CTB is damaged)") from None
    if not compressed.startswith(b'\x1f\x8b\x08'):
        raise _cfg_error(configfile, "Wrong key/IV for this CTB, or damaged CTB data")
    try:
        signed=gzip.decompress(compressed)
    except (OSError, EOFError):
        raise _cfg_error(configfile, "CTB payload cannot be decompressed; check the config and CTB") from None
    require(len(signed)<32*1024*1024 and signed.startswith(b'\xef\xbb\xbf<LTD_CODEPLUG'), 'CTB uncompressed payload invalid')
    sigstart=signed.rfind(b'<SIGNATURE>')
    require(sigstart>0,'CTB signature missing')
    xml=signed[3:sigstart]
    signature=etree.fromstring(signed[sigstart:],etree.XMLParser(resolve_entities=False,no_network=True))
    require(signature.findtext('VERSION')=='1.0','Unsupported signature version')
    n=int.from_bytes(base64.b64decode(signature.findtext('RSAKeyValue/Modulus')),'big')
    e=int.from_bytes(base64.b64decode(signature.findtext('RSAKeyValue/Exponent')),'big')
    rsa=RSAPublicNumbers(e,n).public_key()
    rsa.verify(bytes.fromhex(signature.findtext('DIGEST')),xml.decode('utf-8').encode('utf-16-le'),asym_padding.PKCS1v15(),hashes.SHA1())
    # The original signature verifies against the untouched data. Known old
    # CPS1 illegal XML character references must be repaired ONLY for parsing.
    parse_xml=re.sub(rb'&#xFFFF;',b'&#xFFFD;',xml,flags=re.I)
    root=etree.fromstring(parse_xml,etree.XMLParser(huge_tree=True,no_network=True,resolve_entities=False))
    require(root.tag=='LTD_CODEPLUG','Not a Motorola LTD_CODEPLUG')
    metadata={'type':kind,'ctb_xml_version':root.get('VERSION'),'file_sha256':hashlib.sha256(raw).hexdigest(),
              'verified_original_motorola_signature':True,'xml_sha256':hashlib.sha256(xml).hexdigest()}
    return root,metadata


def child(node,tag,default=None):
    x=node.find(tag)
    if x is None or x.text is None:return default
    return x.text


def refid(node,tag,target_type):
    x=node.find(tag)
    if x is None or x.get('TypeID')!=target_type:return None
    s=(x.text or '').strip()
    if not s.isdigit():return None
    return int(s)


def aliased(name,order,used):
    s=' '.join(str(name or '').split()).strip() or ('Item'+str(order))
    s=s[:16]
    if s.casefold() in used:
        suffix='~'+str(order)
        s=s[:16-len(suffix)]+suffix
    if s.casefold() in used:raise ValueError('Channel name collisions after truncation')
    used.add(s.casefold());return s


def to_bool(s):return str(s or '').strip().lower() in ('1','true','yes','enabled')


def normalize_ctb(source_path,config_path):
    root,meta=decode_ctb(source_path,config_path)
    grp=root.find('.//CNV_PER_CMP_TYPE_GRP')
    require(grp is not None and len(grp)>0,'No conventional personalities in CTB')
    channel_map={};channels=[];used=set();source_channel_ids=[]
    for ix,n in enumerate(grp,1):
        typ=child(n,'CP_PERSTYPE','')
        require(typ in ('ANLGCONV','DGTLCONV6PT25'),f'Unsupported CPS1 personality {typ!r} at {ix}')
        source_id=int(n.get('ListID','-1'))
        require(source_id not in channel_map,f'Duplicate Motorola conventional personality ListID {source_id}')
        source_channel_ids.append(source_id)
        original=child(n,'CP_CNVPERSALIAS',f'Channel {ix}')
        bw=child(n,'CP_CHNLBWDTH','')
        rxkind=child(n,'CP_XSQCHTY','CSQ');txkind=child(n,'CP_TXSQCHTY','CSQ')
        require(rxkind in ('CSQ','TPL','DPL') and txkind in ('CSQ','TPL','DPL'),f'Unsupported analog squelch setting {original}')
        channel={
         'index':ix,'uuid':f'personality-{source_id}','source_name':original,'name':aliased(original,ix,used),
         'mode':'FM' if typ=='ANLGCONV' else 'DMR','rx_mhz':float(child(n,'CP_RXFREQ')),
         'tx_mhz':float(child(n,'CP_TXFREQ')),'rx_only':to_bool(child(n,'CP_RXONLYEN')),
         'power':'Low' if child(n,'CP_TXPWR')=='LOWPWR' else 'Max',
         'timeout':int(child(n,'CP_TOT','0')),'bandwidth':25.0 if '25KHZ' in bw and '12PT5' not in bw else 12.5,
         'color_code':int(child(n,'CP_COLORCODE','0')),'timeslot':2 if child(n,'CP_SLTASSGMNT')=='SLOT2' else 1,
         'rx_tone_type':rxkind,'tx_tone_type':txkind,
         'rx_tone_value':child(n,'CP_RXTPLFREQ','') if rxkind=='TPL' else child(n,'CP_RXDPLCD','') if rxkind=='DPL' else '',
         'tx_tone_value':child(n,'CP_TXTTPLFREQ','') if txkind=='TPL' else child(n,'CP_TXTDPLCD','') if txkind=='DPL' else '',
         'rx_invert':to_bool(child(n,'CP_RXDPLINV')),'tx_invert':to_bool(child(n,'CP_TXDPLINV')),
         'contact_uuid':None,'rxgroup_uuid':None,'scan_roam_uuid':None,'auto_scan':to_bool(child(n,'CP_UTOSCANEN')),
         'vox':to_bool(child(n,'CP_VOXSTATE')),'original_personality_type':typ,
         '_ref_contact':refid(n,'CP_UKPPERS','DIGITAL_UCL_DLL_TYPE'),
         '_ref_rxgroup':refid(n,'CP_TGLISTIT','RX_TG_LIST_DLH_TYPE'),
         '_ref_scan':refid(n,'CP_SCNROAMLISTIT','SCAN_PER_DLH_TYPE'),
         '_ref_scan_alt':refid(n,'CP_SCANPERSLISTIT','SCAN_PER_DLH_TYPE'),
         '_ref_roam':refid(n,'CP_SCNROAMLISTIT','ST_SRCH_DLH_TYPE'),
        }
        require(0<channel['rx_mhz']<1000 and 0<channel['tx_mhz']<1000,'Invalid source frequency')
        channel_map[source_id]=channel;channels.append(channel)

    def group_items(tag,entry):
        n=root.find('.//'+tag)
        return list(n) if n is not None else []
    # Motorola list references are by ListLetID (not by file/XML position).
    contact_map={};contacts=[]
    for g in group_items('DIGITAL_UCL_DLH_TYPE_GRP',''):
        for node in g.findall('DIGITAL_UCL_DLL_TYPE'):
            num=int(node.get('ListLetID','-1'))
            require(num not in contact_map,'Duplicate CTB contact ListLetID')
            typecode=child(node,'DU_CALLTYPE','GRPCALL')
            require(typecode in ('GRPCALL','PRIVCALL','ALLCALL'),'Unknown DMR call type: '+typecode)
            co={'index':len(contacts)+1,'uuid':f'contact-{num}','name':child(node,'DU_CALLALIAS',f'Contact{num}'),
                'id':int(child(node,'DU_CALLLSTID','0')),
                'type':{'GRPCALL':'Group','PRIVCALL':'Private','ALLCALL':'All'}[typecode],'raw_type':typecode,
                'source_listlet_id':num}
            require(0<=co['id']<=16776415,'Invalid DMR contact ID')
            contacts.append(co);contact_map[num]=co
    grps=[];grp_map={}
    for node in group_items('RX_TG_LIST_DLH_TYPE_GRP',''):
        gid=int(node.get('ListID','-1'))
        require(gid not in grp_map,'Duplicate CTB RX group ListID')
        members=[]
        for mem in node.findall('RX_TG_LIST_DLL_TYPE'):
            rid=refid(mem,'RXTG_DGUCLCOMP','DIGITAL_UCL_DLL_TYPE')
            require(rid in contact_map, f'Unknown RX group contact reference {rid}')
            members.append(contact_map[rid]['index'])
        rec={'uuid':f'rxgroup-{gid}','name':child(node.find('RX_TG_LIST_DLH_TYPE'),'RXTG_RXTGLISTALIAS',f'RX Group{gid}'),
             'contact_indices':members,'source_list_id':gid}
        grp_map[gid]=rec
        # Empty CPS default groups have no practical RDB membership.
        if members:grps.append(rec)

    zones=[]
    for node in group_items('ZN_PER_ASGN_DLH_TYPE_GRP',''):
        name=child(node.find('ZN_PER_ASGN_DLH_TYPE'),'ZP_ZONEALIAS',f'Zone{len(zones)+1}')
        members=[]
        for mem in node.findall('ZN_PER_ASGN_DLL_TYPE'):
            ref=refid(mem,'ZP_PERSIT','CNV_PER_CMP_TYPE')
            require(ref in channel_map, f'Unknown zone channel ID {ref} in {name!r}')
            c=channel_map[ref]
            members.append({'source_uuid':c['uuid'],'channel_index':c['index'],'channel_name':c['name']})
        if members:
            zones.append({'index':len(zones)+1,'name':name,'members':members})
    # Scan + roaming: skip empty CPS placeholder lists unless a personality
    # explicitly references them; otherwise preserve all members and IDs.
    lists=[];scan_map={};roam_map={}
    for kind,tag,container,header,alias,membertag,reffield,expected in [
      ('scan','SCAN_PER_DLH_TYPE_GRP','SCAN_PER_DLT_TYPE','SCAN_PER_DLH_TYPE','SP_SCANLISTALIAS','SCAN_PER_DLL_TYPE','SP_CNVPERCOMP','CNV_PER_CMP_TYPE'),
      ('roam','ST_SRCH_DLH_TYPE_GRP','ST_SRCH_DLT_TYPE','ST_SRCH_DLH_TYPE','SSP_SCANLISTALIAS','ST_SRCH_DLL_TYPE','SSP_CNVPERCOMP','CNV_PER_CMP_TYPE')]:
        known={}
        for node in group_items(tag,''):
            i=int(node.get('ListID','-1'))
            require(i not in known,'Duplicate Motorola '+kind+' ListID')
            name=child(node.find(header),alias,f'{kind}{i}')
            members=[]
            for mem in node.findall(membertag):
                uid=refid(mem,reffield,expected)
                require(uid in channel_map,f'Unknown {kind} channel ID {uid} in {name}')
                c=channel_map[uid]
                members.append({'source_uuid':c['uuid'],'channel_index':c['index'],'channel_name':c['name']})
            known[i]={'index':i,'uuid':f'{kind}-{i}','name':name,'type':kind,'members':members}
        for c in channels:
            uid=c['_ref_roam'] if kind=='roam' else (c['_ref_scan'] if c['_ref_scan'] is not None else c['_ref_scan_alt'])
            if uid is not None:require(uid in known,'Channel references nonexistent '+kind+' ListID '+str(uid))
        for i,li in known.items():
            referenced=any(c['_ref_roam']==i if kind=='roam' else c['_ref_scan']==i or c['_ref_scan_alt']==i for c in channels)
            if li['members'] or referenced:
                lists.append(li)
                (scan_map if kind=='scan' else roam_map)[i]=li
    for c in channels:
        # If both are configured, roaming is the selected higher priority list;
        # analog channels must never be assigned a DMR roaming list.
        if c['_ref_roam'] is not None:
            require(c['mode']=='DMR','Analog channel references a roaming list')
            c['scan_roam_uuid']=roam_map[c['_ref_roam']]['uuid']
        else:
            n=c['_ref_scan'] if c['_ref_scan'] is not None else c['_ref_scan_alt']
            if n is not None:c['scan_roam_uuid']=scan_map[n]['uuid']
        co=contact_map.get(c['_ref_contact'])
        if c['_ref_contact'] is not None:require(co is not None,'Unknown TX contact referenced from '+c['source_name'])
        if co:c['contact_uuid']=co['uuid'];c['tx_contact']=co
        else:c['tx_contact']=None
        gr=grp_map.get(c['_ref_rxgroup'])
        if c['_ref_rxgroup'] is not None:require(gr is not None,'Unknown RX group referenced from '+c['source_name'])
        if gr and gr['contact_indices']:c['rxgroup_uuid']=gr['uuid'];c['rx_group']=gr
        else:c['rx_group']=None
        c['scan_roam']=next((li for li in lists if li['uuid']==c['scan_roam_uuid']),None)
        for t in ('_ref_contact','_ref_rxgroup','_ref_scan','_ref_scan_alt','_ref_roam'):c.pop(t)
    identity=root.find('.//RC_SUBSCRIBERID')
    if identity is None:identity=root.find('.//RC_SUBSCRIBERID_CPS')
    require(identity is not None and identity.text is not None,'CTB radio DMR ID missing')
    rid=int(identity.text)
    require(1<=rid<=16776415,'Invalid CTB subscriber ID')
    out={'subscriber_id':rid,'source_file':Path(source_path).name,'source_sha256':meta['file_sha256'],
         'source_format':'Motorola CPS1 CTB '+meta['type'],'source_datamodel':meta['ctb_xml_version'],
         'channels':channels,'zones':zones,'contacts':contacts,'rx_groups':grps,'scan_roam_lists':lists,'two_tone':read_motorola_qcii(root)}
    return out,meta




def main():
    """Optional source inspection. To create destination files, run script #2."""
    p=argparse.ArgumentParser(description="Inspect a Motorola CPS1 CTB; for export, run 2_*_Creator.py")
    p.add_argument('source_ctb', type=Path, nargs='?', help='Optional source .ctb; auto-detect when only one is present')
    p.add_argument('--ctbimport', type=Path, metavar='CTB', help='Select the CTB when multiple candidates exist')
    p.add_argument('--config', type=Path, default=None)
    args=p.parse_args()
    if args.source_ctb is not None and args.ctbimport is not None:
        p.error('Give the CTB either positionally or with --ctbimport, not both')
    try:
        source_ctb=one_file('.ctb', __file__, explicit=args.ctbimport or args.source_ctb)
    except DiscoveryError as exc:
        print('CTB selection: '+str(exc), file=sys.stderr)
        print('Manual command: python '+Path(__file__).name+' --ctbimport radio.ctb', file=sys.stderr)
        sys.exit(2)
    args.config=find_config(args.config,__file__)
    try:
        load_aes_config(args.config)
        model,meta=normalize_ctb(source_ctb,args.config)
    except CodeplugConfigError as exc:
        print(exc,file=sys.stderr)
        sys.exit(2)
    except ValueError as exc:
        print('CTB inspection failed: '+str(exc),file=sys.stderr)
        sys.exit(1)
    print(json.dumps({'source':source_ctb.name,'archive_type':meta['type'],
        'signature_verified':meta['verified_original_motorola_signature'],
        'channels':len(model['channels']),'contacts':len(model['contacts']),
        'zones':len(model['zones']),'qcii_decode':len(model['two_tone']['decode']),
        'qcii_encode':len(model['two_tone']['encode'])},indent=2))
    print('To create output files, run the 2_*_Creator.py script.')


if __name__=='__main__':main()
