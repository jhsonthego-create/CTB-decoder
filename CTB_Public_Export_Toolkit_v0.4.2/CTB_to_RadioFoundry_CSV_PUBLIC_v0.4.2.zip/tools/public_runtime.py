#!/usr/bin/env python3
"""Shared, standard-library-only public CLI discovery and local extraction helpers.

Never includes private config bytes in output, logs or distributed packages.
Extracted programming may contain sensitive IDs and donor settings: keep local.
"""
from __future__ import annotations
import hashlib
import json
import re
import struct
from datetime import datetime
from pathlib import Path

class DiscoveryError(ValueError):
    pass


def find_config(explicit, script_file):
    """An explicit path wins; otherwise CWD first, then script directory."""
    if explicit is not None:
        return Path(explicit)
    for base in (Path.cwd(), Path(script_file).resolve().parent):
        candidate = base / 'codeplug.cfg'
        if candidate.is_file():
            return candidate
    # Let the existing large decoder banner explain the missing config.
    return Path.cwd() / 'codeplug.cfg'


def candidates(suffix, script_file, exclude_outputs=True):
    """Search CWD, falling back to the script directory; never pick arbitrarily."""
    for folder in dict.fromkeys((Path.cwd().resolve(), Path(script_file).resolve().parent)):
        matches = sorted((p for p in folder.iterdir()
                          if p.is_file() and p.suffix.lower() == suffix.lower() and
                          (not exclude_outputs or not generated_name(p))),
                         key=lambda p:p.name.casefold())
        if matches:
            return matches
    return []


def generated_name(p):
    n=p.stem.lower()
    return bool(re.search(r'(?:-out|-converted|-cs711|-cs811|-pd782|-foundry)(?:$|[-_])',n))


def one_file(suffix, script_file, explicit=None):
    if explicit is not None:
        f=Path(explicit)
        if not f.is_file():
            raise DiscoveryError(f'Explicit input does not exist: {f}')
        return f
    found=candidates(suffix,script_file)
    if len(found)!=1:
        raise DiscoveryError(f'Expected exactly one source {suffix} file; found {len(found)}: '+
                             ', '.join(f.name for f in found))
    return found[0]


def check_output(target,*inputs):
    target=Path(target)
    if target.exists():
        raise DiscoveryError(f'Output already exists; refusing overwrite: {target}')
    if target.resolve() in {Path(p).resolve() for p in inputs}:
        raise DiscoveryError(f'Output matches an input file: {target}')
    audit=target.with_suffix('.audit.json')
    if audit.exists():
        raise DiscoveryError(f'Audit report already exists; refusing overwrite: {audit}')
    if audit.resolve() in {Path(p).resolve() for p in inputs}:
        raise DiscoveryError(f'Audit report conflicts with an input: {audit}')
    return target


def dump_json(path,value):
    Path(path).write_text(json.dumps(value,indent=2,ensure_ascii=False,default=str)+'\n',encoding='utf8')


class ExtractSession:
    """One local timestamp per invocation, even if CS711+CS811 both export."""
    def __init__(self,enabled=True, base_dir=None):
        self.enabled=enabled
        self.root=Path(base_dir) if base_dir else Path.cwd()
        self.stamp=datetime.now().strftime('%Y%m%d_%H%M')
        self.paths={}
        self.names=set()

    def _new_folder(self,source,kind):
        source=Path(source)
        key=(source.resolve(),kind)
        if key in self.paths:
            return None
        stem=re.sub(r'[^\w. -]+','_',source.stem,flags=re.UNICODE).strip(' .') or kind
        # Include extension only when otherwise colliding in this invocation.
        proposed=f'{stem}_{self.stamp}'
        if proposed.casefold() in self.names:
            proposed=f'{stem}_{kind}_{self.stamp}'
        path=self.root / proposed
        i=2
        while path.exists() or path.name.casefold() in self.names:
            path=self.root / f'{proposed}-{i}'
            i+=1
        path.mkdir(parents=True,exist_ok=False)
        self.paths[key]=path
        self.names.add(path.name.casefold())
        return path

    def ctb(self,ctb,config,decoder):
        if not self.enabled:return
        folder=self._new_folder(ctb,'ctb')
        if folder is None:return
        from lxml import etree
        root,metadata=decoder.decode_ctb(ctb,config)
        model,_=decoder.normalize_ctb(ctb,config)
        (folder/'decrypted_codeplug.xml').write_bytes(etree.tostring(root,encoding='UTF-8',xml_declaration=True))
        dump_json(folder/'decoded_model.json',model)
        dump_json(folder/'metadata.json',{
            'source':Path(ctb).name,'source_sha256':hashlib.sha256(Path(ctb).read_bytes()).hexdigest(),
            'archive_type':metadata['type'],'verified_original_motorola_signature':metadata['verified_original_motorola_signature'],
            'note':'The XML is normalized for parsing; it is not the original signed byte stream. No AES key or IV is exported.'})
        print('EXTRACTED CTB to',folder)

    def rdb(self,donor):
        if not self.enabled:return
        folder=self._new_folder(donor,'rdb')
        if folder is None:return
        b=Path(donor).read_bytes()
        if len(b)!=376832:
            raise ValueError('Unknown Connect Systems donor layout; cannot extract records safely')
        (folder/'original_records.bin').write_bytes(b)
        name=lambda v:v.decode('utf-16le','replace').split('\0')[0]
        count=struct.unpack_from('<H',b,0x15082)[0]
        if count>1000:raise ValueError('Invalid RDB channel inventory')
        channels=[]
        for i in range(count):
            rec=b[0x1d580+i*32:0x1d580+(i+1)*32]
            channels.append({'index':i+1,'name':name(b[0x15880+i*32:0x15880+(i+1)*32]),
                'tx_mhz':round(struct.unpack_from('<I',rec,0)[0]/1e6,6),
                'rx_mhz':round(struct.unpack_from('<I',rec,4)[0]/1e6,6),
                'mode':'FM' if rec[8]==0x17 else 'DMR' if rec[8]==0x14 else f'unknown 0x{rec[8]:02X}',
                'raw_record_hex':rec.hex()})
        dump_json(folder/'decoded_records.json',{'donor':Path(donor).name,
            'model':b[0x2000:0x2005].decode('ascii','replace'),
            'observed_channel_count':count,'channels':channels,
            'warning':'Other fields are preserved in original_records.bin, not claimed to be fully interpreted.'})
        dump_json(folder/'metadata.json',{'sha256':hashlib.sha256(b).hexdigest(),
            'length':len(b),'binary_encrypted':False})
        print('EXTRACTED RDB to',folder)

    def rcdx(self,donor,plaintext):
        if not self.enabled:return
        folder=self._new_folder(donor,'rcdx')
        if folder is None:return
        from _internal.rcdx_records import scan_all_sections,parse_plaintext
        data=bytes(plaintext)
        (folder/'decrypted_payload.bin').write_bytes(data)
        dump_json(folder/'section_index.json',scan_all_sections(data))
        dump_json(folder/'decoded_records.json',parse_plaintext(data))
        dump_json(folder/'metadata.json',{'donor':Path(donor).name,
            'donor_sha256':hashlib.sha256(Path(donor).read_bytes()).hexdigest(),
            'decoded_payload_sha256':hashlib.sha256(data).hexdigest(),
            'note':'Only supported record types are interpreted; unknown fields remain in the raw decoded payload. Programming may be sensitive.'})
        print('EXTRACTED RCDX to',folder)
