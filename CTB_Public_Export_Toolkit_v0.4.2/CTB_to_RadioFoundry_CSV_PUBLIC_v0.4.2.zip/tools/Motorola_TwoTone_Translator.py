#!/usr/bin/env python3
"""Read Motorola CPS1 Quick Call II systems and transmit contacts.
No Connect Systems, Hytera, or Foundry binary tables are edited here.
"""
from __future__ import annotations
from decimal import Decimal, InvalidOperation


def _text(node,tag,default=None):
    item=node.find(tag)
    return default if item is None or item.text is None else item.text.strip()


def _frequency(raw,context):
    try:hz=Decimal(raw)
    except (InvalidOperation,TypeError):raise ValueError(f'{context}: missing/invalid frequency {raw!r}')
    if hz<Decimal('200.0') or hz>Decimal('2500.0') or hz*10!=(hz*10).to_integral_value():
        raise ValueError(f'{context}: frequency {raw!r} is outside observed 200–2500 Hz / 0.1 Hz resolution')
    return int(hz*10)


def _tone_fields(node,first,second,context):
    return _frequency(_text(node,first),context+' A'),_frequency(_text(node,second),context+' B')


def _source_contacts(root):
    grp=root.find('.//QCII_UCL_DLH_TYPE_GRP')
    if grp is None:return []
    return grp.findall('.//QCII_UCL_DLL_TYPE')


def read_motorola_qcii(root):
    """Separate QCII decode systems from QCII transmit contacts.

    Motorola initializes most untouched CPS1 CTBs with an inactive Sys1 and
    a 288.5/288.5-Hz Call1. These are placeholders, NOT programmed tones.
    """
    systems={}
    for n in root.findall('.//QCII_SYS_CMP_TYPE_GRP/QCII_SYS_CMP_TYPE'):
        sid=int(n.get('ListID','-1'))
        if sid in systems:raise ValueError('Duplicate Motorola QCII system ID '+str(sid))
        systems[sid]=n
    decoded=[];system_audit=[];active_systems=set()
    for sid,n in systems.items():
        calltype=_text(n,'QCIISYS_CALLTYPE','NONE')
        alias=_text(n,'QCIISYS_QCIISYSALIAS',f'Sys{sid}')
        fmt=_text(n,'QCIISYS_FORMATTYPE','')
        if calltype=='NONE':
            system_audit.append({'source_id':sid,'name':alias,'state':'inactive-default-or-unconfigured','imported':False})
            continue
        if calltype!='SELECTIVE_CALL':
            raise ValueError(f'QCII system {alias!r}: unsupported call type {calltype!r}')
        a,b=_tone_fields(n,'QCIISYS_TONEARF','QCIISYS_TONEBRF',alias)
        if fmt not in ('CALLFMT_AB','CALLFMT_AB_LONG_C','CALLFMT_AB_CD'):
            raise ValueError(f'QCII system {alias!r}: unsupported format {fmt!r}')
        decoded.append({'source_kind':'system A-B','source_id':sid,'name':alias+' A-B',
                        'format':'Two Tone','tone_a_tenths':a,'tone_b_tenths':b})
        if fmt=='CALLFMT_AB_LONG_C':
            c=_frequency(_text(n,'QCIISYS_TONECRF'),alias+' Long C')
            decoded.append({'source_kind':'system Long C','source_id':sid,'name':alias+' Long C',
                            'format':'Long Tone','tone_a_tenths':c,'tone_b_tenths':c})
        elif fmt=='CALLFMT_AB_CD':
            c,d=_tone_fields(n,'QCIISYS_TONECRF','QCIISYS_TONEDRF',alias+' C-D')
            decoded.append({'source_kind':'system C-D','source_id':sid,'name':alias+' C-D',
                            'format':'Two Tone','tone_a_tenths':c,'tone_b_tenths':d})
        active_systems.add(sid)
        system_audit.append({'source_id':sid,'name':alias,'state':calltype,'format':fmt,
                             'imported':True,'decode_definitions':2 if fmt in ('CALLFMT_AB_LONG_C','CALLFMT_AB_CD') else 1,
                             'note':'Combined Motorola format split into source tone definitions; destination support and call logic vary'})

    encoded=[];contact_audit=[];contact_ids=set()
    for n in _source_contacts(root):
        cid=int(n.get('ListLetID','-1'))
        if cid in contact_ids:raise ValueError('Duplicate Motorola QCII contact ID '+str(cid))
        contact_ids.add(cid)
        name=_text(n,'QU_CALLENTRYALIAS',f'Call{cid}')
        fmt=_text(n,'QU_CALLFORMAT','')
        sid=int(_text(n,'QU_QCIISYS','-1'))
        if sid not in systems:
            raise ValueError(f'QCII contact {name!r} references missing system {sid}')
        a,b=_tone_fields(n,'QU_TONEATXFRE','QU_TONEBTXFRE',name)
        # The CPS-created empty template is not a user-programmed QCII entry.
        is_default=(cid==0 and name=='Call1' and fmt=='TWO_TONE'
                    and a==2885 and b==2885)
        if is_default:
            contact_audit.append({'source_id':cid,'name':name,'state':'Motorola-default-placeholder','imported':False})
            continue
        if fmt not in ('TWO_TONE','LONG_TONE'):
            raise ValueError(f'QCII contact {name!r}: unsupported format {fmt!r}')
        # In a LONG_TONE contact the B frequency is disabled. Ignore it.
        if fmt=='LONG_TONE':b=a
        encoded.append({'source_id':cid,'source_system_id':sid,'name':name,
                        'format':'Two Tone' if fmt=='TWO_TONE' else 'Long Tone',
                        'tone_a_tenths':a,'tone_b_tenths':b})
        contact_audit.append({'source_id':cid,'name':name,'state':'programmed','imported':True,
                              'format':fmt,'tone_a_hz':a/10,'tone_b_hz':b/10})
    return {'decode':decoded,'encode':encoded,'source_systems':system_audit,
            'source_contacts':contact_audit,'motorola_placeholder_contacts_skipped':sum(not x['imported'] for x in contact_audit)}



if __name__ == "__main__":
    print('*****************************************************************************\n*****************************************************************************\n*************                                           *********************\n*************  THIS IS NOT AN INDEPENDENT SCRIPT        *********************\n*************                                           *********************\n*****************************************************************************\n*****************************************************************************')
    print("\n  This is an internal helper; it does no conversion when run directly.")
    print("  Run the 2_*_Creator.py script instead.\n")
