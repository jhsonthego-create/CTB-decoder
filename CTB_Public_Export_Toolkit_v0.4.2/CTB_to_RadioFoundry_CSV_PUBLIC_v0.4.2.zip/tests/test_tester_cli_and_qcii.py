"""Regression: single-source CTB tester discovery + A-B/C-D Quick Call II.
All test codeplugs are synthetic; no private keys or source radio data bundled.
"""
import contextlib
import importlib
import io
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from lxml import etree

PKG=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(PKG))
translator=importlib.import_module('tools.Motorola_TwoTone_Translator')


def make_qcii(fmt='CALLFMT_AB_CD',fourth='928.1'):
    root=etree.Element('LTD_CODEPLUG')
    group=etree.SubElement(root,'QCII_SYS_CMP_TYPE_GRP')
    sysnode=etree.SubElement(group,'QCII_SYS_CMP_TYPE',ListID='1')
    for tag,value in (
        ('QCIISYS_CALLTYPE','SELECTIVE_CALL'),
        ('QCIISYS_QCIISYSALIAS','Sys1'),
        ('QCIISYS_FORMATTYPE',fmt),
        ('QCIISYS_TONEARF','617.4'),
        ('QCIISYS_TONEBRF','726.8'),
        ('QCIISYS_TONECRF','810.2'),
        ('QCIISYS_TONEDRF',fourth),
    ):
        etree.SubElement(sysnode,tag).text=value
    return root

class TestPublicCTBTester(unittest.TestCase):
    def test_ab_cd_keeps_both_tone_pairs(self):
        got=translator.read_motorola_qcii(make_qcii())
        self.assertEqual(len(got['decode']),2)
        self.assertEqual([(x['tone_a_tenths'],x['tone_b_tenths']) for x in got['decode']],
                         [(6174,7268),(8102,9281)])
        self.assertEqual([x['source_kind'] for x in got['decode']],['system A-B','system C-D'])
        self.assertEqual(got['source_systems'][0]['decode_definitions'],2)

    def test_ab_cd_missing_d_tone_fails_closed(self):
        with self.assertRaisesRegex(ValueError,'missing/invalid frequency'):
            translator.read_motorola_qcii(make_qcii(fourth='invalid'))

    def test_unsupported_formats_still_fail_closed(self):
        with self.assertRaisesRegex(ValueError,'unsupported format'):
            translator.read_motorola_qcii(make_qcii(fmt='CALLFMT_UNKNOWN'))

    def test_autodetect_one_ctb_without_positional_argument(self):
        dec=importlib.import_module('1_CTB_Decode_Tester')
        with tempfile.TemporaryDirectory() as d:
            cwd=Path(d);(cwd/'radio.ctb').write_bytes(b'synthetic-test')
            old=os.getcwd()
            try:
                os.chdir(cwd)
                with patch.object(sys,'argv',[str(PKG/'1_CTB_Decode_Tester.py')]), \
                     patch.object(dec,'load_aes_config'), \
                     patch.object(dec,'normalize_ctb',return_value=(
                         {'channels':[1],'contacts':[],'zones':[],'two_tone':{'decode':[],'encode':[]}},
                         {'type':'TEST','verified_original_motorola_signature':True})), \
                     io.StringIO() as out, contextlib.redirect_stdout(out):
                    dec.main()
                    text=out.getvalue()
                    self.assertIn('"source": "radio.ctb"',text)
            finally:
                os.chdir(old)

    def test_multiple_ctb_shows_manual_command_no_config_needed(self):
        dec=importlib.import_module('1_CTB_Decode_Tester')
        with tempfile.TemporaryDirectory() as d:
            cwd=Path(d)
            (cwd/'one.ctb').write_bytes(b'one')
            (cwd/'two.ctb').write_bytes(b'two')
            old=os.getcwd()
            try:
                os.chdir(cwd)
                with patch.object(sys,'argv',[str(PKG/'1_CTB_Decode_Tester.py')]), \
                     io.StringIO() as err, contextlib.redirect_stderr(err):
                    with self.assertRaises(SystemExit) as se:
                        dec.main()
                    self.assertEqual(se.exception.code,2)
                    self.assertIn('--ctbimport radio.ctb',err.getvalue())
            finally:
                os.chdir(old)

if __name__=='__main__':
    unittest.main()
