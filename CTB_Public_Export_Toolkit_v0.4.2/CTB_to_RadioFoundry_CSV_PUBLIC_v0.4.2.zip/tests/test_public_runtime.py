"""Release regression tests: discovery and local extraction behavior, no secrets."""
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from tools.public_runtime import find_config,one_file,candidates,check_output,DiscoveryError,ExtractSession

class TestPublicRuntime(unittest.TestCase):
    def test_cwd_first_config_and_explicit_override(self):
        with tempfile.TemporaryDirectory() as t:
            top=Path(t);script=top/'scripts';run=top/'working';script.mkdir();run.mkdir()
            (script/'codeplug.cfg').write_text('script')
            (run/'codeplug.cfg').write_text('working')
            import os
            old=Path.cwd()
            try:
                os.chdir(run)
                self.assertEqual(find_config(None,script/'test.py'),run/'codeplug.cfg')
                self.assertEqual(find_config(top/'explicit.cfg',script/'test.py'),top/'explicit.cfg')
                (run/'codeplug.cfg').unlink()
                self.assertEqual(find_config(None,script/'test.py'),script/'codeplug.cfg')
            finally:os.chdir(old)
    def test_inputs_are_not_guessed_and_outputs_are_excluded(self):
        with tempfile.TemporaryDirectory() as t:
            top=Path(t);(top/'one.ctb').write_bytes(b'1');(top/'two.ctb').write_bytes(b'2')
            (top/'clean.rdb').write_bytes(b'')
            (top/'clean-out.rdb').write_bytes(b'')
            import os
            old=Path.cwd()
            try:
                os.chdir(top)
                with self.assertRaises(DiscoveryError):one_file('.ctb',top/'script.py')
                self.assertEqual([x.name for x in candidates('.rdb',top/'script.py')],['clean.rdb'])
            finally:os.chdir(old)
    def test_never_overwrite_outputs_or_audits(self):
        with tempfile.TemporaryDirectory() as t:
            top=Path(t);out=top/'radio-out.rdb';source=top/'radio.ctb'
            self.assertEqual(check_output(out,source),out)
            (top/'radio-out.audit.json').write_text('prior audit')
            with self.assertRaises(DiscoveryError):check_output(out,source)
            (top/'radio-out.audit.json').unlink();out.write_bytes(b'prior output')
            with self.assertRaises(DiscoveryError):check_output(out,source)
    def test_single_timestamp_and_existing_folder_is_renamed(self):
        with tempfile.TemporaryDirectory() as t:
            session=ExtractSession(base_dir=t)
            original=session.stamp
            f=Path(t)/('radio_'+original);f.mkdir()
            new=session._new_folder(Path(t)/'radio.ctb','ctb')
            self.assertTrue(new.is_dir())
            self.assertEqual(session.stamp,original)
            self.assertTrue(new.name.endswith('-2'))
            self.assertIsNone(session._new_folder(Path(t)/'radio.ctb','ctb'))
    def test_direct_helper_displays_large_banner_only(self):
        helper=Path(__file__).resolve().parents[1]/'tools/Motorola_TwoTone_Translator.py'
        result=subprocess.run([sys.executable,str(helper)],capture_output=True,text=True)
        self.assertEqual(result.returncode,0,result.stderr)
        self.assertIn('THIS IS NOT AN INDEPENDENT SCRIPT',result.stdout)
        self.assertIn('does no conversion',result.stdout)

if __name__=='__main__':unittest.main()
