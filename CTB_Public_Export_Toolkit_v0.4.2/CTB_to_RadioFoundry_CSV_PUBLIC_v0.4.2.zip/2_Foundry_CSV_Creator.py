#!/usr/bin/env python3
"""Export Motorola CPS1 CTB to Radio Foundry six-file CSV ZIP.
RUN THIS SCRIPT (#2). Script #1 reads CTB; script #3 parses Motorola QCII.
"""
from __future__ import annotations
import argparse,csv,hashlib,io,json,zipfile,sys,importlib
from tools.public_runtime import find_config,one_file,check_output,DiscoveryError,ExtractSession
from pathlib import Path

decoder=importlib.import_module("1_CTB_Decode_Tester")
normalize_ctb=decoder.normalize_ctb

def name16(s,idx,taken):
 s=' '.join(str(s or '').replace('|','/').replace('\r',' ').replace('\n',' ').split()).strip() or 'Unnamed'
 n=s[:16]
 if n.casefold() not in taken:
  taken.add(n.casefold());return n
 suffix='~'+str(idx)
 n=s[:16-len(suffix)]+suffix
 while n.casefold() in taken:
  suffix='~'+str(idx)+'x';n=s[:16-len(suffix)]+suffix
 taken.add(n.casefold());return n

def fmt_tone(ch,direction):
 kind=ch[direction+'_tone_type'];value=ch[direction+'_tone_value']
 if kind=='TPL':
  try:return f'{float(value):.1f}'
  except:return ''
 if kind=='DPL':
  return 'D'+str(value or '023').zfill(3)+('I' if ch.get(direction+'_invert') else 'N')
 return ''

def read_csv(z,name):
 data=z.read(name).decode('utf-8-sig');return list(csv.DictReader(io.StringIO(data))),list(csv.DictReader(io.StringIO(data)).fieldnames)

def csvbytes(cols,rows):
 out=io.StringIO(newline='');w=csv.DictWriter(out,fieldnames=cols,lineterminator='\r\n',extrasaction='ignore');w.writeheader();w.writerows(rows);return ('\ufeff'+out.getvalue()).encode('utf-8')

def dm32(model, schema_zip, output_zip):
 out=Path(output_zip)
 with zipfile.ZipFile(schema_zip) as original:
  schemas={name:read_csv(original,name) for name in original.namelist() if name.endswith('.csv')}
  target_channels=[];zrows=[];crow=[];grows=[]
  used_contacts=set()
  name_by_id={co['index']:name16(co['name'],co['index'],used_contacts) for co in model['contacts']}
  contact_slot_by_uuid={co['uuid']:co['index'] for co in model['contacts']}
  for c in model['contacts']:
   crow.append({'Number':c['index'],'Name':name_by_id[c['index']],'ID':c['id'],'Call Type':c['type'],'Timeslot':''})
  for g in model['rx_groups']:
   grows.append({'Number':len(grows)+1,'Name':g['name'],'Contacts':'|'.join(name_by_id[i] for i in g['contact_indices'] if i in name_by_id)})
  for ch in model['channels']:
   row=dict.fromkeys(schemas['channels.csv'][1],'')
   row.update({'Number':ch['index'],'Name':ch['name'],'Mode':ch['mode'],
     'RX Frequency (MHz)':f"{ch['rx_mhz']:.6f}", 'TX Frequency (MHz)':f"{ch['tx_mhz']:.6f}",
     'Power':ch['power'],'Timeout (s)':ch['timeout'],'Bandwidth (kHz)':('25' if ch['bandwidth']==25 else '12.5') if ch['mode']=='FM' else '12.5',
     'RX Tone':fmt_tone(ch,'rx') if ch['mode']=='FM' else '',
     'TX Tone':fmt_tone(ch,'tx') if ch['mode']=='FM' else '',
     'Squelch':'0', 'Color Code':ch['color_code'] if ch['mode']=='DMR' else '1',
     'Timeslot':ch['timeslot'] if ch['mode']=='DMR' else '1',
     'TX Contact':name_by_id[contact_slot_by_uuid[ch['contact_uuid']]] if ch['mode']=='DMR' and ch['tx_contact'] else '',
     'RX Group List':ch['rx_group']['name'] if ch['mode']=='DMR' and ch['rx_group'] else '',
     'DMR ID':model['subscriber_id'] if ch['mode']=='DMR' else '', 'RX Only':'Yes' if ch['rx_only'] else 'No',
     'All Skip':'No','Zone Skip':'No','VOX':'Yes' if ch['vox'] else 'No',
     'No Beep':'No','No Eco':'No','DMO':'No',
     'Roaming':'Yes' if ch['scan_roam'] and ch['scan_roam']['type']=='roam' else 'No',
     'Talker Alias TS1':'0','Talker Alias TS2':'0','Use Location':'No',
     'Latitude':'','Longitude':'','SFR':'No','SFR A':'0','SFR B':'0'})
   target_channels.append(row)
  for z in model['zones']:
   zrows.append({'Name':z['name'],'Channels':'|'.join(m['channel_name'] for m in z['members'] if m['channel_name'])})
  replace={'channels.csv':target_channels,'contacts.csv':crow,'zones.csv':zrows,'rx-group-lists.csv':grows}
  with zipfile.ZipFile(out,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
   for name in original.namelist():
    if name in replace:z.writestr(name,csvbytes(schemas[name][1],replace[name]))
    else:z.writestr(name,original.read(name))
 # Verify import references and completeness with real written zip.
 with zipfile.ZipFile(out) as z:
  rows,cols=read_csv(z,'channels.csv');zone_rows,_=read_csv(z,'zones.csv');contacts,_=read_csv(z,'contacts.csv')
  assert len(rows)==len(model['channels'])
  assert len(zone_rows)==len(model['zones'])
  assert set(z.namelist())==set(schemas)
  names=[x['Name'].casefold() for x in rows];assert len(names)==len(set(names))
  known=set(x['Name'] for x in rows)
  for zone in zone_rows:
   for name in zone['Channels'].split('|'):
    if name:assert name in known,(zone['Name'],name)
  knowncontact=set(x['Name'] for x in contacts)
  for c in rows:
   if c['TX Contact']:assert c['TX Contact'] in knowncontact,(c['Name'],c['TX Contact'])
 return out


REQUIRED={'channels.csv','contacts.csv','zones.csv','rx-group-lists.csv','dtmf-contacts.csv','aprs.csv'}

def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('source_ctb',type=Path,nargs='?',help='Legacy positional CTB source')
 p.add_argument('--ctbimport',type=Path,help='Explicit source CTB')
 p.add_argument('--config',type=Path,default=None)
 p.add_argument('--schema',type=Path,default=Path(__file__).resolve().with_name('radiofoundry_blank_schema.zip'))
 p.add_argument('--output',type=Path,help='Default: SOURCE-out.zip')
 p.add_argument('--no-extract',action='store_true',help='Skip saving decoded CTB files locally')
 a=p.parse_args()
 a.config=find_config(a.config,__file__)
 decoder.load_aes_config(a.config)  # ALWAYS show the config banner first.
 manual='python 2_Foundry_CSV_Creator.py --ctbimport radio.ctb'
 if a.source_ctb and a.ctbimport:p.error('Use either a positional CTB or --ctbimport, not both')
 try:a.source_ctb=one_file('.ctb',__file__,a.ctbimport or a.source_ctb)
 except DiscoveryError as exc:p.error(f'{exc}\nManual command: {manual}')
 if a.output is None:a.output=a.source_ctb.with_name(a.source_ctb.stem+'-out.zip')
 for file in (a.source_ctb,a.schema):
  if not file.is_file():p.error('Missing input: '+str(file))
 try:check_output(a.output,a.source_ctb,a.schema,a.config)
 except DiscoveryError as exc:p.error(str(exc))
 with zipfile.ZipFile(a.schema) as z:
  if set(z.namelist())!=REQUIRED:p.error('Schema ZIP must contain six original Radio Foundry CSV names')
  for name in REQUIRED:
   all_rows=list(csv.reader(io.StringIO(z.read(name).decode('utf-8-sig'))))
   if not all_rows or not all_rows[0]:p.error('Missing CSV headers: '+name)
   if any(any(cell.strip() for cell in row) for row in all_rows[1:]):
    p.error('Schema must contain headers only; remove donor/sample rows from '+name)
 model,metadata=normalize_ctb(a.source_ctb,a.config)
 if any(m['channel_index'] is None for z in model['zones'] for m in z['members']):
  raise ValueError('Unresolved CTB zone channel reference')
 if any(m['channel_index'] is None for li in model['scan_roam_lists'] for m in li['members']):
  raise ValueError('Unresolved CTB scan/roam channel reference')
 # The six-file Foundry CSV schema has no native Motorola QCII/scan-list tables.
 unmapped={
  'motorola_qcii_decode':len(model['two_tone']['decode']),
  'motorola_qcii_encode':len(model['two_tone']['encode']),
  'motorola_scan_lists':sum(li['type']=='scan' for li in model['scan_roam_lists']),
  'motorola_roaming_lists':sum(li['type']=='roam' for li in model['scan_roam_lists']),
 }
 a.output.parent.mkdir(parents=True,exist_ok=True)
 try:
  dm32(model,a.schema,a.output)
  with zipfile.ZipFile(a.output) as z:
   if z.testzip() is not None:raise ValueError('CSV ZIP integrity failure')
   rows=list(csv.DictReader(io.StringIO(z.read('channels.csv').decode('utf-8-sig'))))
   if len(rows)!=len(model['channels']):raise ValueError('CSV channel count mismatch')
   invalid=[(x['Number'],x['Bandwidth (kHz)']) for x in rows if x['Bandwidth (kHz)'] not in ('12.5','25')]
   if invalid:raise ValueError('Unsupported Foundry bandwidth: '+str(invalid[:3]))
 except Exception:
  a.output.unlink(missing_ok=True)
  raise
 audit={'source_ctb':a.source_ctb.name,'archive_type':metadata['type'],
        'source_sha256':model['source_sha256'],'output_sha256':hashlib.sha256(a.output.read_bytes()).hexdigest(),
        'channels':len(model['channels']),'zones':len(model['zones']),'contacts':len(model['contacts']),
        'rx_groups':len(model['rx_groups']),'unmapped_features':unmapped,
        'warning':'Six-file Foundry schema has no QCII/scan-list native tables. Their definitions are NOT imported. Roaming flag on channels is preserved where representable. Review CPS before programming.',
        'cps_import_verified':False}
 a.output.with_suffix('.audit.json').write_text(json.dumps(audit,indent=2)+'\n',encoding='utf8')
 print(json.dumps(audit,indent=2))
 ExtractSession(not a.no_extract).ctb(a.source_ctb,a.config,decoder)
if __name__=='__main__':
 try:main()
 except decoder.CodeplugConfigError as exc:
  print(exc,file=sys.stderr)
  sys.exit(2)
